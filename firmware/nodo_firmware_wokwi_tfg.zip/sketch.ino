#include <WiFi.h>
#include <PubSubClient.h>

// =======================
// CONFIGURACIÓN WIFI
// =======================

const char* ssid = "Wokwi-GUEST";
const char* password = "";

// =======================
// CONFIGURACIÓN MQTT
// =======================

const char* mqtt_server = "broker.emqx.io";
const int mqtt_port = 1883;

const char* topicCommand = "locks/1/command";
const char* topicState = "locks/1/state";

// =======================
// HARDWARE
// =======================

#define LOCK_LED 2

// =======================
// OBJETOS
// =======================

WiFiClient espClient;
PubSubClient client(espClient);

// =======================
// ESTADO DE LA CERRADURA
// =======================

bool locked = true;

// =======================
// FUNCIONES
// =======================

void publishState() {

  if (locked) {

    client.publish(
      topicState,
      "LOCKED",
      true
    );

    Serial.println("Estado enviado: LOCKED");

  } else {

    client.publish(
      topicState,
      "UNLOCKED",
      true
    );

    Serial.println("Estado enviado: UNLOCKED");

  }
}

void lockDoor() {

  locked = true;

  digitalWrite(LOCK_LED, HIGH);

  publishState();
}

void unlockDoor() {

  locked = false;

  digitalWrite(LOCK_LED, LOW);

  publishState();
}

void callback(char* topic, byte* payload, unsigned int length) {

  String message = "";

  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  Serial.println("Comando recibido:");
  Serial.println(message);

  if (message == "OPEN") {

    unlockDoor();

  } else if (message == "CLOSE") {

    lockDoor();

  }
}

void connectWiFi() {

  Serial.print("Conectando WiFi");

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {

    delay(500);
    Serial.print(".");

  }

  Serial.println();
  Serial.println("WiFi conectado");
  Serial.println(WiFi.localIP());
}

void connectMQTT() {

  while (!client.connected()) {

    Serial.print("Conectando MQTT...");

    String clientId = "ESP32_LOCK_";
    clientId += String(random(1000));

    if (client.connect(clientId.c_str())) {

      Serial.println(" OK");

      client.subscribe(topicCommand);

      Serial.println("Suscrito a:");
      Serial.println(topicCommand);

      publishState();

    } else {

      Serial.print(" Error: ");
      Serial.println(client.state());

      delay(2000);
    }
  }
}

// =======================
// SETUP
// =======================

void setup() {

  Serial.begin(115200);

  pinMode(LOCK_LED, OUTPUT);

  digitalWrite(LOCK_LED, HIGH);

  connectWiFi();

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);

  randomSeed(micros());

  lockDoor();
}

// =======================
// LOOP
// =======================

unsigned long lastTelemetry = 0;

void loop() {

  if (!client.connected()) {
    connectMQTT();
  }

  client.loop();

  // Telemetría cada 10 segundos
  if (millis() - lastTelemetry > 10000) {

    lastTelemetry = millis();

    publishState();
  }
}